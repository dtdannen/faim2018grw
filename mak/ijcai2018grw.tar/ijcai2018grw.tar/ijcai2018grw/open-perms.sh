

chmod 644 *.html *.php
chmod 711 css fonts/ images/ js/ talks/ papers/
chmod 644 css/* fonts/* images/* js/* talks/* papers/*

