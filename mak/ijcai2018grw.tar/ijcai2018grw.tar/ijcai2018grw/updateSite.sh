
echo "Copy the following line and run it at the cygwin prompt"
scp -r *  makrob@makro.ink:/home/makrob/makro.ink/ijcai2017grw/

